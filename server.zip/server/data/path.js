const path = require('path')

module.exports = {
    StudentAchievePath: path.join(__dirname, '/stuAchievement.txt'),
    AchievePath: path.join(__dirname, '/achievement.txt'),
    StudentPath: path.join(__dirname, '/student.txt'),
    TeacherPath: path.join(__dirname, '/teacher.txt')
}